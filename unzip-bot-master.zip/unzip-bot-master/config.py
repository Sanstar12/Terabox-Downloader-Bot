# Copyright (c) 2022 - 2024 EDM115
import os


class Config:
    # 🔹 Telegram App credentials
    APP_ID = 25214632
    API_HASH = "85f9204d557b13f5b336bd67dc073a46"
    BOT_TOKEN = "8433438462:AAGl5mhttfnewNGm5HwRsLurv0mRWTb2Tts"

    # 🔹 Bot owner / admin
    BOT_OWNER = 6618712970

    # 🔹 MongoDB connection
    MONGODB_URL = "mongodb+srv://firstmong065:BGQoHt83kaIIen52@cluster0.mwmz9.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
    MONGODB_DBNAME = "Unzipper_Bot"

    # 🔹 Logs / channel setup
    LOGS_CHANNEL = -1002346542951

    # 🔹 Paths and bot behavior
    DOWNLOAD_LOCATION = f"{os.path.dirname(__file__)}/Downloaded"
    THUMB_LOCATION = f"{os.path.dirname(__file__)}/Thumbnails"
    TG_MAX_SIZE = 2097152000
    MAX_MESSAGE_LENGTH = 4096
    CHUNK_SIZE = 1024 * 1024 * 10  # 10 MB
    BOT_THUMB = f"{os.path.dirname(__file__)}/bot_thumb.jpg"
    MAX_CONCURRENT_TASKS = 75
    MAX_TASK_DURATION_EXTRACT = 120 * 60  # 2 hours
    MAX_TASK_DURATION_MERGE = 240 * 60    # 4 hours